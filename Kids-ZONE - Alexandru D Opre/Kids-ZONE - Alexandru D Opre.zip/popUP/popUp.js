function popUP(){
	window.open ("popUP/popUp.html","mywindow","menubar=1,resizable=no,width=700px,height=500px");

}

